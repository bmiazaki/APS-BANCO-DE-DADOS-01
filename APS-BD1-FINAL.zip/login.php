<?php
session_start();
include ('conex.php');

if (empty($_POST['login_usuario']) || empty($_POST['senha_usuario'])) {
	header ('Location: index.php');
	exit();
}

$usuario = mysqli_real_escape_string($conexao, $_POST['login_usuario']);
$senha = mysqli_real_escape_string($conexao, $_POST['senha_usuario']);

$query = "SELECT id_usuario, login_usuario FROM USUARIO WHERE login_usuario = '{$usuario}' and senha_usuario = md5('{$senha}')";
//echo $query; exit; significa que usuario/senha existem 

$result = mysqli_query($conexao, $query);

$row = mysqli_num_rows($result);
//echo $row; exit; -> verificação validada se exibir 1

if ($row == 1) {
	$_SESSION['login_usuario'] = $usuario;
	header ('Location: playlist.php');
	exit();
} else {
	header ('Location: index.php');
	exit();
}