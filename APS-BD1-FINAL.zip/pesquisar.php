<?php
	
	
//PESQUISAR
	$pesquisar = $_POST['pesquisar'];
	$sql = "SELECT * FROM PLAYLIST WHERE login_usuario = '{$login_usuario}' and nome_playlist LIKE '%$pesquisar%'";
	$resultado = mysqli_query($conexao, $sql);
	while ($row = mysqli_fetch_array($resultado)) {
		$grupo[] = $row;
	}
	return $grupo;
	
	
	
//CONEXAO
	$grupo = NULL;
	$login_usuario = $_SESSION['login_usuario'];
	$musicasbd = abrirBanco();
	$pesquisar = $_POST['pesquisar'];
	
	$sql = "SELECT * FROM PLAYLIST WHERE login_usuario = '{$login_usuario}' and nome_playlist LIKE '%$pesquisar%'";
	$resultado = $musicasbd->query($sql);
	$pesquisa = mysqli_fetch_assoc($resultado);
	//$resultado = mysqli_query($conexao, $sql);
	while ($row = mysqli_fetch_array($resultado)) {
		$grupo[] = $row;
	}
	return $grupo;