<?php
	session_start();
?>

<!DOCTYPE html>
<html lang = "pt-br">
	<head>
		<meta charset = "utf-8">
		<title>CADASTRO</title>
	</head>
	<body>
		<h2>CADASTRO</h2>
		<?php
			if (isset($_SESSION['msg'])) {
				echo $_SESSION['msg'];
				unset ($_SESSION['msg']);
			}
		?>
		<form method = "POST" action = "cadastro.php">
			<label>Nome</label>
			<input type = "text" name = "nome_usuario" placeholder = "Digite o seu nome"><br><br>
			
			<label>Usuário</label>
			<input type = "text" name = "login_usuario" placeholder = "Digite o seu usuário"><br><br>
			
			<label>Senha</label>
			<input type = "password" name = "senha_usuario" placeholder = "Digite a sua senha"><br><br>
			
			<input type = "submit" name = "cadastrar" value = "Cadastrar">
		</form>
	</body>
</html>