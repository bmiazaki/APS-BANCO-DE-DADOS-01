<?php
	session_start();
?>

<!DOCTYPE html>
<html lang = "pt-br">
	<head>
		<meta charset = "utf-8">
		<title>LOGIN</title>
	</head>
	<body>
		<h2 style="color:pink;">LOGIN</h2>
		<?php
			if (isset($_SESSION['msg'])) {
				echo $_SESSION['msg'];
				unset ($_SESSION['msg']);
			}
		?>
		<form method = "POST" action = "login.php">
			<label>Usuário</label>
			<input type = "text" name = "login_usuario" placeholder = "Digite o seu usuário"><br><br>
			
			<label>Senha</label>
			<input type = "password" name = "senha_usuario" placeholder = "Digite a sua senha"><br><br>
			
			<input type = "submit" name = "acessar" value = "Acessar"><br><br>
		</form>
		<form method = "POST" action = "index_cadastro.php">
			<input type = "submit" name = "cadastrar" value = "Cadastrar">
		</form>
	</body>
</html>