<?php

if (isset($_POST["acao"])) {
	if ($_POST["acao"] == "editar") {
		editarUsuario();
	}
	if ($_POST["acao"] == "excluir") {
		excluirUsuario();
	}
}

function abrirBanco() {
	$conn = new mysqli("localhost", "root", "", "musicasbd");
	return $conn;
}

function editarUsuario() {
	$musicasbd = abrirBanco();
	$sql = "UPDATE USUARIO SET login_usuario = '{$_POST["login_usuario"]}', nome_usuario = '{$_POST["nome_usuario"]}', senha_usuario = '{$_POST["senha_usuario"]}' WHERE id_usuario = '{$_POST["id_usuario"]}'";
	$musicasbd->query($sql);
	$musicasbd->close();
	//mensagem de edição feita com sucesso
	voltarPlaylist();
}

function selectIdUsuario($login_usuario) {
	$musicasbd = abrirBanco();
	$sql = "SELECT * FROM USUARIO WHERE login_usuario = '{$login_usuario}'";
	$resultado = $musicasbd->query($sql);
	$usuario = mysqli_fetch_assoc($resultado);
	return $usuario;
}

function excluirUsuario() {
	$musicasbd = abrirBanco();
	$sql = "DELETE FROM USUARIO WHERE id_usuario = '{$_POST["id_usuario"]}'";
	$musicasbd->query($sql);
	$musicasbd->close();
	voltarIndex();
}

function voltarPlaylist() {
	header('Location: playlist.php');	
}

function voltarIndex() {
	header('Location: index.php');
}