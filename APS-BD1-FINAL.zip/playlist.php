<?php
//include("verifica.php");
include("conexao.php");
$grupo = selectAllPlaylist();
?>

<html>
	<head>
		<meta charset = "UTF-8">
		<body style="background-image:url('fundo-rosa-claro-png.jpg');"> </body>		
		<title>Projeto BD1</title>
	</head>
	<body>
		<h1 style="font-family: candara;">Olá, <?php echo $_SESSION['login_usuario'];?></h1> 
		<a href = "logout.php"><p style="text-align:right;">LOGOUT</p></a>		
		<a href = "index_editar.php"> EDITAR SEUS DADOS </a> <br><br>
		<br><br><a href = "inserir.php"> Add Playlist </a><br><br>
		
		<table border = "1">
			<thead>
				<tr>
					<th>Nome</th>
					<th>Editar</th>
					<th>Excluir</th>
				</tr>
			</thead>
			<tbody>
				<?php
					if ($grupo) {
						foreach ($grupo as $playlist) { ?>
							<tr>
								<td><?=$playlist["nome_playlist"]?></td>
								<td>
									<form name = "alterar" action = "alterar.php" method = "POST">
										<input type = "hidden" name = "id_usuario" class = "form-field" value = "<?php echo $id_usuario?>">
										<input type = "hidden" name = "id_playlist" value = <?=$playlist["id_playlist"]?> />
										<input type = "submit" value = "Editar" name = "Editar" />									
									</form>
								</td>
								<td>
									<form name = "Excluir" action = "conexao.php" method = "POST">
										<input type = "hidden" name = "id_playlist" value = "<?=$playlist["id_playlist"]?>" />
										<input type = "hidden" name = "acao" value = "excluir" />
										<input type = "submit" value = "Excluir" name = "excluir" />									
									</form>
								</td>
							</tr>
						<?php }
					}
					?>
			</tbody>			
		</table>
	</body>
</html>