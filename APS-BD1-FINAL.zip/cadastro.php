<?php
session_start();
include ("conex.php");

$nome = mysqli_real_escape_string($conexao, trim($_POST['nome_usuario'])); //trim = tira o espaço do inicio e do fim da string
$login = mysqli_real_escape_string($conexao, trim($_POST['login_usuario']));
$senha = mysqli_real_escape_string($conexao, trim(md5($_POST['senha_usuario']))); // md5 criptografa a senha no db

$sql = "select count(*) as total from usuario where login_usuario = '$login'";
$result = mysqli_query($conexao, $sql);
$row = mysqli_fetch_assoc($result);

if($row['total'] == 1) {
	$_SESSION['usuario_existe'] = true;
	header('Location: index_cadastro.php');
	exit;
}

$sql = "insert into usuario (nome_usuario, login_usuario, senha_usuario) values ('$nome', '$login', '$senha')";

if ($conexao->query($sql) === TRUE) { //validar consulta// === comparação booleana em php
	$_SESSION['status_cadastro'] = true;
}

$conexao->close();

header ('Location: index.php');
exit;



?>