<?php
//include("verifica.php");
include("conexao.php");
$grupo = selectAllPlaylist();
?>

<table border = "1">
			<thead>
				<tr>
					<th>Nome</th>
					<th>Editar</th>
					<th>Excluir</th>
				</tr>
			</thead>
			<tbody>
				<?php
					if ($grupo) {
						foreach ($grupo as $playlist) { ?>
							<tr>
								<td><?=$playlist["nome_playlist"]?></td>
								<td>
									<form name = "alterar" action = "alterar.php" method = "POST">
										<input type = "hidden" name = "id_usuario" class = "form-field" value = "<?php echo $id_usuario?>">
										<input type = "hidden" name = "id_playlist" value = <?=$playlist["id_playlist"]?> />
										<input type = "submit" value = "Editar" name = "Editar" />									
									</form>
								</td>
								<td>
									<form name = "Excluir" action = "conexao.php" method = "POST">
										<input type = "hidden" name = "id_playlist" value = "<?=$playlist["id_playlist"]?>" />
										<input type = "hidden" name = "acao" value = "excluir" />
										<input type = "submit" value = "Excluir" name = "excluir" />									
									</form>
								</td>
							</tr>
						<?php }
					}
					?>
			</tbody>			
		</table>
		<br><br><a href = "playlist.php">VOLTAR</a><br><br>