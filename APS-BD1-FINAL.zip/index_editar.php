<?php
include "editar.php";
include "conex.php";
include "verifica.php";
$usuario = selectIdUsuario($_SESSION["login_usuario"]);
//echo $usuario['id_usuario'];
?>


<head>
	<meta charset = "UTF-8">
	<title>UPDATE CADASTRO</title>
</head>
<body>
	<h1>UPDATE CADASTRO</h1>
	<h2>Seus dados</h2>
	
	<form name = "usuario" action = "editar.php" method = "POST">
		<table border = "1">
			<tbody>
				<form>
					<tr>
						<td>Nome do usuário</td>
						<td><input type = "text" name = "nome_usuario" value = "<?=$usuario["nome_usuario"]?>" /></td>
					</tr>
					<tr>
						<td>Usuário/Login</td>
						<td><input type = "text" name = "login_usuario" value = "<?=$usuario["login_usuario"]?>" /></td>
					</tr>
					<tr>
						<td>Senha do usuário</td>
						<td><input type = "password" name = "senha_usuario" value = "<?=$usuario["senha_usuario"]?>" /></td>					
					</tr>
					<tr>
						<td>
							<input type = "hidden" name = "acao" value = "editar"/>
							<input type = "hidden" name = "id_usuario" value = "<?=$usuario["id_usuario"]?>"/>
							
						</td>
						<td><input type = "submit" value = "Enviar" name = "Enviar" /></td>
				</form>
				<form name = "Excluir" action = "editar.php" method = "POST">
					<input type = "hidden" name = "id_usuario" value = "<?=$usuario["id_usuario"]?>" />
					<input type = "hidden" name = "acao" value = "excluir" />
					<input type = "submit" value = "Excluir conta" name = "excluir" />									
				</form>
				</tr>
			</tbody>
		</table>
	</form>
</body>