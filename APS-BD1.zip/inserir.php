<?php
include("verifica.php");
include("editar.php");
$login_usuario = $_SESSION['login_usuario'];
	$musicasbd = abrirBanco();
	$sql = "SELECT * FROM USUARIO WHERE login_usuario = '{$login_usuario}'";
	$resultado = $musicasbd->query($sql);
	$usuario = mysqli_fetch_assoc($resultado);
?>	

<meta charset = "UTF-8">
<form name = "playlist" action = "conexao.php" method = "POST">
	<table border = "1">
		<tbody>
			<tr>			
			<input type = "hidden" name ="id_usuario" value = <?php echo $usuario['id_usuario']?> />
				<td>Nome da Playlist</td>
				<td><input type = "text" name = "nome_playlist" value = "" /></td>
			</tr>
			<tr>
				<td><input type = "hidden" name = "acao" value = "inserir"/></td>
				<td><input type = "submit" value = "Enviar" name = "Enviar"/></td>
			</tr>
		</tbody>
	</table>
</form>