<?php
session_start();

if(!$_SESSION['login_usuario']) {
	header ('Location: index.php');
	exit();
}