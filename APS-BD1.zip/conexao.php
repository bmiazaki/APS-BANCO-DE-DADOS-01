<?php

/*$musicasbd = abrirBanco();
$id_usuario = "SELECT id_usuario FROM PLAYLIST WHERE login_usuario = '$login_usuario'";
echo $id_usuario;*/

if (isset($_POST["acao"])) {
	if ($_POST["acao"] == "inserir") {
		inserirPlaylist();
	}
	if ($_POST["acao"] == "alterar") {
		alterarPlaylist();
	}
	if ($_POST["acao"] == "excluir") {
		excluirPlaylist();
	}
}

function abrirBanco() {
	$conexao = new mysqli("localhost", "root", "", "musicasbd");
	return $conexao;
}

function inserirPlaylist() {
	$musicasbd = abrirBanco();
	$sql = "INSERT INTO PLAYLIST (nome_playlist, id_usuario) VALUES ('{$_POST["nome_playlist"]}','{$_POST["id_usuario"]}')";
	$musicasbd->query($sql);
	$musicasbd->close();
	voltarPlaylist();
}

function alterarPlaylist() {
	$musicasbd = abrirBanco();
	$sql = "UPDATE playlist SET nome_playlist = '{$_POST["nome_playlist"]}' WHERE id_playlist = '{$_POST["id_playlist"]}'";
	$musicasbd->query($sql);
	$musicasbd->close();
	voltarPlaylist();
}

function excluirPlaylist() {
	$musicasbd = abrirBanco();
	$sql = "DELETE FROM PLAYLIST WHERE id_playlist = '{$_POST["id_playlist"]}'";
	$musicasbd->query($sql);
	$musicasbd->close();
	voltarPlaylist();
}

function selectAllPlaylist() {
$login_usuario = $_SESSION['login_usuario'];
	$musicasbd = abrirBanco();
	$sql = "SELECT * FROM USUARIO WHERE login_usuario = '{$login_usuario}'";
	$resultado = $musicasbd->query($sql);
	$usuario = mysqli_fetch_assoc($resultado);
	$grupo = NULL;
	$musicasbd = abrirBanco();
	$sql = "SELECT * FROM PLAYLIST WHERE id_usuario = '{$usuario['id_usuario']}'ORDER BY nome_playlist";
	$resultado = $musicasbd->query($sql);
	while ($row = mysqli_fetch_array($resultado)) {
		$grupo[] = $row;
	}
	return $grupo;
}

function selectIdPlaylist($id_playlist) {
	$musicasbd = abrirBanco();
	$sql = "SELECT * FROM PLAYLIST WHERE id_playlist = ".$id_playlist;
	$resultado = $musicasbd->query($sql);
	$playlist = mysqli_fetch_assoc($resultado);
	return $playlist;
}

function voltarPlaylist() {
	header("Location: playlist.php");	
}

?>